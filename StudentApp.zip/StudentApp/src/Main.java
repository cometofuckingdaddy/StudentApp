import java.io.BufferedReader;
import java.io.Console;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Objects;
public class Main {
    public static void main(String[] args) throws IOException {
        Hello();

    }

    public static void Hello() throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("_______________________________");
        System.out.println("Hello, Teacher.");
        System.out.println("_______________________________");
        System.out.println("You can start a lesson");
        System.out.println("_______________________________");
        System.out.println("Input s, if you want to start.");
        System.out.println("_______________________________");
        System.out.println("or input another symbol to exit!");
        System.out.println("_______________________________");
        String answer = reader.readLine();
        if (Objects.equals(answer, "s")) {
            UseCommands();
        } else {
            System.out.println("We were hoping you would teach a class :(");
            System.exit(0);
        }
    }

    private static void UseCommands() throws IOException {
        int count = 0;
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        ArrayList<Student> students = new ArrayList<Student>();
        ArrayList<Student> studentsWithStatus = new ArrayList<Student>();
        Class lilclass = new Class(students);
        System.out.println("Input how much student do ypu want in class. More than 0, less than 51");
        String str = reader.readLine();
        int countOfStudents = CheckAnother(str);
        for (int i = 0; i < countOfStudents; i++) {
            students.add(new Student(Student.RandomPresent()));
        }
        ShowCommands();
        while (students.size() != 0) {
            String comm = reader.readLine();
            if (Objects.equals(comm, "/r")) {
                Actions(students, studentsWithStatus, lilclass, count);
            } else if (Objects.equals(comm, "/l")) {
                Class.ShowList(studentsWithStatus);
            } else if (Objects.equals(comm, "/h")) {
                ShowCommands();
            } else {
                System.out.println("Incorrect command, please input again");
                System.out.println("______________________" + "\n");
            }

        }
        System.out.println("________________");
        System.out.println("Lesson is over. All students answered");
        System.out.println("Goodbye Teacher");
        System.out.println("Here are your ratings today: ");
        Class.ShowList(studentsWithStatus);
        System.out.println("Total number of students: " + countOfStudents);
        System.out.println("Number of students that absent of class: " + (countOfStudents - studentsWithStatus.size()));

    }

    private static void ShowCommands() {
        System.out.println("Input /r if you want to choose random student");
        System.out.println("Input /l to get list of students who received a grade");
        System.out.println("Input /h help, lists commands and how to use them");
    }

    private static void Actions(ArrayList<Student> students, ArrayList<Student> studentsWithStatus, Class lilclass, int count)
            throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        int numberOfStudent = Class.ChooseRandom(students);
        if (numberOfStudent > students.size()) {
            while (numberOfStudent > students.size()) {
                numberOfStudent--;
            }
        }
        if (students.get(numberOfStudent).presence) {
            System.out.println("Give the student a grade: " + "\n");
            String num = reader.readLine();
            students.get(numberOfStudent).mark = Check(num);
            lilclass.marks.add(students.get(numberOfStudent).mark);
            studentsWithStatus.add(students.get(numberOfStudent));
            students.remove(numberOfStudent);
        } else {
            System.out.println("This Student absent from class");
            students.remove(numberOfStudent);
        }
        System.out.println("\n");
        System.out.println("Type command");
    }

    public static int Check(String num) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        while (!isNumber(num)) {
            System.out.println("Its not a number, please input again" + "\n");
            num = reader.readLine();
        }
        int mark = Integer.parseInt(num);
        while (mark < 1 || mark > 10) {
            System.out.println("Number less than 1 or more than 10, please input again");
            num = reader.readLine();
            mark = Integer.parseInt(num);
        }
        return mark;
    }
    public static int CheckAnother(String num) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        while (!isNumber(num)) {
            System.out.println("Its not a number, please input again" + "\n");
            num = reader.readLine();
        }
        int mark = Integer.parseInt(num);
        while (mark < 1 || mark > 30) {
            System.out.println("Number less than 1 or more than 30, please input again");
            num = reader.readLine();
            mark = Integer.parseInt(num);
        }
        return mark;
    }


    public static Boolean isNumber(String str) {
        boolean isOnlyDigits = true;
        for (int i = 0; i < str.length(); i++) {
            if (!Character.isDigit(str.charAt(i))) {
                isOnlyDigits = false;
            }
        }
        return isOnlyDigits;
    }
}


class Student {

    int mark;
    Boolean presence;

    Student(Boolean presence) {
        this.presence = presence;
    }

    public static Boolean RandomPresent() {
        int a = (int) (Math.random() * 100) + 1;
        return a % 2 == 0;
    }

}

class Class {
    ArrayList<Integer> marks = new ArrayList<Integer>();
    public ArrayList<Student> students = new ArrayList<Student>();

    Class(ArrayList<Student> students) {
        this.students = students;
    }

    public static int ChooseRandom(ArrayList<Student> students) {
        if (students.size() == 1) {
            return 0;
        }
        return (int) (Math.random() * students.size());
    }

    public static void ShowList(ArrayList<Student> students) {
        System.out.println("______________________");
        System.out.println("List of students marks: ");
        for (int i = 0; i < students.size(); i++) {
            System.out.println("Student N" + (i + 1) + " had a " + students.get(i).mark);
        }
    }
}